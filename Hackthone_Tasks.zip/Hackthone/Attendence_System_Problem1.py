import pandas as pd

data = {
    "Name":   ["Ali", "Sara", "Ahmed", "Hina", "Bilal", "Zara",
               "Ali", "Sara", "Ahmed", "Hina", "Bilal", "Zara"],
    "Status": ["Present", "Absent", "Present", "present", "ABSENT", "Present",
               "Present", "Absent", "Present", "Present", "Absent", "Present"],
}

df = pd.DataFrame(data)

# --- Cleaning ---
df["Name"]   = df["Name"].str.strip().str.title()
df["Status"] = df["Status"].str.strip().str.lower()

# Remove duplicates (same student, same status entry duplicated)
df = df.drop_duplicates()

# --- Analysis ---
summary = (
    df.assign(is_present=df["Status"].eq("present"))
      .groupby("Name")["is_present"]
      .agg(["sum", "count"])
      .rename(columns={"sum": "Present", "count": "Total"})
)

summary["Attendance %"] = (summary["Present"] / summary["Total"] * 100).round(2)

def status_label(p):
    if p >= 90: return "Excellent"
    elif p >= 75: return "Good"
    return "Warning"

summary["Status"] = summary["Attendance %"].apply(status_label)

print(summary)
print("\nStudents below 75%:")
print(summary[summary["Attendance %"] < 75].index.tolist())