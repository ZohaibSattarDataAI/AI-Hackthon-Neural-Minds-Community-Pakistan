"""
Inventory Management System
A simple shop inventory tracker with menu-driven operations.
"""

# Global inventory store: {product_name: {"price": float, "quantity": int}}
inventory = {}


# ---------- Helpers ----------

def clean_name(name):
    """Normalize product name: trim spaces and Title Case."""
    return name.strip().title()


def total_inventory_value():
    """Return sum of (price × quantity) for all products."""
    return sum(item["price"] * item["quantity"] for item in inventory.values())


def ask_number(prompt, cast=float):
    """Prompt user for a number and return it, or None on invalid input."""
    raw = input(prompt).strip()
    try:
        value = cast(raw)
    except ValueError:
        print("Invalid number. Try again.")
        return None
    if value < 0:
        print("Value cannot be negative.")
        return None
    return value


# ---------- Core Actions ----------

def show_products():
    """Print all products in a table with total value."""
    print("\n" + "=" * 58)
    print(f"{'PRODUCT':<20}{'PRICE':>12}{'QTY':>10}{'VALUE':>14}")
    print("-" * 58)

    if not inventory:
        print("  Inventory is empty.")
    else:
        for name, item in inventory.items():
            value = item["price"] * item["quantity"]
            print(f"{name:<20}{item['price']:>12.2f}{item['quantity']:>10}{value:>14.2f}")

    print("=" * 58)
    print(f"Total Inventory Value: {total_inventory_value():.2f}")
    print("=" * 58)


def add_product():
    """Add a new product after validating input and duplicates."""
    name = clean_name(input("Product name: "))
    if not name:
        print("Product name cannot be empty.")
        return
    if name in inventory:
        print(f"'{name}' already exists. Use update instead.")
        return

    price = ask_number("Price: ", float)
    if price is None:
        return

    quantity = ask_number("Quantity: ", int)
    if quantity is None:
        return

    inventory[name] = {"price": price, "quantity": quantity}
    print(f"Added '{name}'.")


def update_quantity():
    """Update the quantity of an existing product."""
    name = clean_name(input("Product name to update: "))
    if name not in inventory:
        print(f"'{name}' not found.")
        return

    quantity = ask_number("New quantity: ", int)
    if quantity is None:
        return

    inventory[name]["quantity"] = quantity
    print(f"Updated '{name}' → quantity {quantity}.")


# ---------- Menu ----------

def show_menu():
    print("\n--- INVENTORY MENU ---")
    print("1. Show products")
    print("2. Add product")
    print("3. Update quantity")
    print("4. Total value")
    print("5. Exit")


def main():
    # Sample starting data
    inventory.update({
        "Apple": {"price": 50.0, "quantity": 20},
        "Milk":  {"price": 120.0, "quantity": 10},
        "Bread": {"price": 80.0, "quantity": 5},
    })

    actions = {
        "1": show_products,
        "2": add_product,
        "3": update_quantity,
        "4": lambda: print(f"\nTotal Inventory Value: {total_inventory_value():.2f}"),
    }

    while True:
        show_menu()
        choice = input("Choose (1-5): ").strip()

        if choice == "5":
            print("Goodbye.")
            break

        action = actions.get(choice)
        if action:
            action()
        else:
            print("Invalid choice. Enter 1-5.")


if __name__ == "__main__":
    main()